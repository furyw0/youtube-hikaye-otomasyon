"""
Coqui TTS Server - Sistem Tray GUI
Minimal arayüz: Başlat/Durdur, Tunnel URL
"""

import sys
import threading
import logging
import webbrowser
from typing import Optional

try:
    import pystray
    from PIL import Image, ImageDraw
    HAS_GUI = True
except ImportError:
    HAS_GUI = False
    print("GUI için pystray ve Pillow gerekli: pip install pystray Pillow")

from config import SERVER_HOST, SERVER_PORT

logger = logging.getLogger(__name__)


def create_icon_image(color: str = "green") -> "Image":
    """Basit bir tray ikonu oluştur"""
    size = 64
    image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    
    # Arka plan daire
    colors = {
        "green": (76, 175, 80, 255),   # Çalışıyor
        "yellow": (255, 193, 7, 255),  # Bekleniyor
        "red": (244, 67, 54, 255),     # Hata
        "gray": (158, 158, 158, 255),  # Kapalı
    }
    fill_color = colors.get(color, colors["gray"])
    
    # Daire çiz
    margin = 4
    draw.ellipse([margin, margin, size - margin, size - margin], fill=fill_color)
    
    # 🐸 emoji yerine "T" harfi
    try:
        draw.text((size // 3, size // 4), "T", fill="white")
    except:
        pass
    
    return image


class TrayApp:
    """Sistem tray uygulaması"""
    
    def __init__(self):
        self.icon: Optional[pystray.Icon] = None
        self.server_thread: Optional[threading.Thread] = None
        self.tunnel_url: Optional[str] = None
        self.is_running = False
        
    def start_server(self):
        """Sunucuyu arka planda başlat"""
        if self.is_running:
            return
            
        from main import app
        import uvicorn
        
        def run():
            uvicorn.run(
                app,
                host=SERVER_HOST,
                port=SERVER_PORT,
                log_level="warning"
            )
        
        self.server_thread = threading.Thread(target=run, daemon=True)
        self.server_thread.start()
        self.is_running = True
        
        self.update_icon("green")
        logger.info("Sunucu başlatıldı")
    
    def stop_server(self):
        """Sunucuyu durdur (process kill gerekir)"""
        # Thread olarak çalıştığı için doğrudan durdurulamaz
        # Kullanıcıya uygulamayı kapatmasını söyle
        logger.info("Sunucuyu durdurmak için uygulamayı kapatın")
    
    def copy_url(self):
        """Tunnel URL'ini panoya kopyala"""
        if self.tunnel_url:
            try:
                import pyperclip
                pyperclip.copy(self.tunnel_url)
                logger.info(f"URL kopyalandı: {self.tunnel_url}")
            except ImportError:
                # pyperclip yoksa log'a yaz
                logger.info(f"URL: {self.tunnel_url}")
                print(f"\nTunnel URL: {self.tunnel_url}\n")
    
    def open_local(self):
        """Yerel sunucuyu tarayıcıda aç"""
        webbrowser.open(f"http://{SERVER_HOST}:{SERVER_PORT}/docs")
    
    def update_icon(self, color: str):
        """İkon rengini güncelle"""
        if self.icon:
            self.icon.icon = create_icon_image(color)
    
    def set_tunnel_url(self, url: str):
        """Tunnel URL'ini ayarla"""
        self.tunnel_url = url
        self.update_menu()
    
    def update_menu(self):
        """Menüyü güncelle"""
        if self.icon:
            self.icon.menu = self.create_menu()
    
    def create_menu(self) -> pystray.Menu:
        """Tray menüsü oluştur"""
        items = [
            pystray.MenuItem(
                "🟢 Coqui TTS Server",
                None,
                enabled=False
            ),
            pystray.Menu.SEPARATOR,
        ]
        
        # Tunnel URL
        if self.tunnel_url:
            items.append(pystray.MenuItem(
                f"📋 URL: {self.tunnel_url[:40]}...",
                self.copy_url
            ))
        else:
            items.append(pystray.MenuItem(
                "⏳ Tunnel bağlanıyor...",
                None,
                enabled=False
            ))
        
        items.extend([
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("📖 API Docs", self.open_local),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("❌ Çıkış", self.quit),
        ])
        
        return pystray.Menu(*items)
    
    def quit(self):
        """Uygulamayı kapat"""
        if self.icon:
            self.icon.stop()
        sys.exit(0)
    
    def run(self):
        """Tray uygulamasını başlat"""
        if not HAS_GUI:
            print("GUI desteği yok, sadece sunucu modunda çalışıyor...")
            from main import main
            main()
            return
        
        # Sunucuyu başlat
        self.start_server()
        
        # Tunnel başlat
        from tunnel_manager import tunnel
        try:
            tunnel.start(on_url=self.set_tunnel_url)
        except Exception as e:
            logger.warning(f"Tunnel başlatılamadı: {e}")
        
        # Tray ikonu oluştur
        self.icon = pystray.Icon(
            "Coqui TTS",
            create_icon_image("green"),
            "Coqui TTS Server",
            self.create_menu()
        )
        
        logger.info("Sistem tray uygulaması başlatıldı")
        self.icon.run()


def main():
    """GUI uygulamasını başlat"""
    app = TrayApp()
    app.run()


if __name__ == "__main__":
    main()

