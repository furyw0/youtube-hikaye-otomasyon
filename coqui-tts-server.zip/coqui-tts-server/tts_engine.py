"""
Coqui TTS Engine - XTTS v2 Wrapper
"""

import os
import torch
import logging
from pathlib import Path

# Coqui TTS lisansını otomatik kabul et
os.environ["COQUI_TOS_AGREED"] = "1"

# PyTorch 2.6+ uyumluluğu için weights_only=False ayarla
# TTS modelleri güvenilir kaynaktan geldiği için bu güvenli
_original_torch_load = torch.load
def _patched_torch_load(*args, **kwargs):
    kwargs.setdefault('weights_only', False)
    return _original_torch_load(*args, **kwargs)
torch.load = _patched_torch_load

from TTS.api import TTS

from config import TTS_MODEL, VOICES_DIR, USE_GPU

logger = logging.getLogger(__name__)


class TTSEngine:
    """XTTS v2 TTS Engine"""
    
    def __init__(self):
        self.tts = None
        self.device = None
        self.model_loaded = False
        
    def initialize(self):
        """TTS modelini yükle"""
        try:
            # GPU kontrolü
            if USE_GPU and torch.cuda.is_available():
                self.device = "cuda"
                logger.info(f"GPU kullanılıyor: {torch.cuda.get_device_name(0)}")
            else:
                self.device = "cpu"
                logger.info("CPU kullanılıyor (daha yavaş olacak)")
            
            # Model yükle
            logger.info(f"TTS modeli yükleniyor: {TTS_MODEL}")
            self.tts = TTS(TTS_MODEL).to(self.device)
            self.model_loaded = True
            logger.info("TTS modeli başarıyla yüklendi")
            
        except Exception as e:
            logger.error(f"TTS modeli yüklenemedi: {e}")
            raise
    
    def generate_speech(
        self, 
        text: str, 
        language: str, 
        voice_id: str,
        output_path: Path
    ) -> Path:
        """
        Metni sese çevir
        
        Args:
            text: Seslendirilecek metin
            language: Dil kodu (tr, en, de, vb.)
            voice_id: Referans ses dosyası ID'si
            output_path: Çıktı dosyası yolu
            
        Returns:
            Oluşturulan ses dosyasının yolu
        """
        if not self.model_loaded:
            raise RuntimeError("TTS modeli yüklenmemiş")
        
        # Referans ses dosyasını bul
        voice_path = VOICES_DIR / f"{voice_id}.wav"
        if not voice_path.exists():
            raise FileNotFoundError(f"Referans ses bulunamadı: {voice_id}")
        
        logger.info(f"Ses üretiliyor: {len(text)} karakter, dil={language}, voice={voice_id}")
        
        try:
            # Ses üret
            self.tts.tts_to_file(
                text=text,
                speaker_wav=str(voice_path),
                language=language,
                file_path=str(output_path)
            )
            
            logger.info(f"Ses üretildi: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"Ses üretimi hatası: {e}")
            raise
    
    def get_status(self) -> dict:
        """Engine durumunu döndür"""
        return {
            "model_loaded": self.model_loaded,
            "device": self.device,
            "gpu": self.device == "cuda",
            "gpu_name": torch.cuda.get_device_name(0) if self.device == "cuda" else None,
            "model": TTS_MODEL
        }


# Singleton instance
engine = TTSEngine()

