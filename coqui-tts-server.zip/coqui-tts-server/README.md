# Coqui TTS Server

YouTube Hikaye Otomasyon uygulaması için yerel TTS (Text-to-Speech) sunucusu.
XTTS v2 modelini kullanarak yüksek kaliteli ses klonlama ve çoklu dil desteği sağlar.

## 🎯 Özellikler

- **XTTS v2 Modeli**: Yüksek kaliteli ses klonlama
- **17 Dil Desteği**: Türkçe, İngilizce, Almanca, Fransızca ve daha fazlası
- **GPU Hızlandırma**: CUDA destekli GPU ile hızlı ses üretimi
- **Cloudflare Tunnel**: Sabit IP olmadan güvenli uzaktan erişim
- **Sistem Tray**: Minimal arayüz ile kolay kullanım

## 📋 Gereksinimler

### Yazılım
- Python 3.10+
- CUDA destekli GPU (önerilir) veya CPU
- cloudflared (Cloudflare Tunnel için)

### cloudflared Kurulumu

**Windows (winget ile - Önerilen):**
```bash
winget install --id Cloudflare.cloudflared
```

**Manuel İndirme:**
- 64-bit: https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe
- 32-bit: https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-386.exe

İndirilen dosyayı `cloudflared.exe` olarak PATH'e ekleyin veya bu klasöre koyun.

## 🚀 Kurulum

### 1. Python Bağımlılıkları

```bash
# Sanal ortam oluştur (önerilir)
python -m venv venv
venv\Scripts\activate  # Windows
# veya
source venv/bin/activate  # Linux/Mac

# Bağımlılıkları kur
pip install -r requirements.txt
```

### 2. İlk Çalıştırma

```bash
python main.py
```

İlk çalıştırmada XTTS v2 modeli indirilecek (~2GB). Bu işlem bir kerelik yapılır.

### 3. GUI ile Çalıştırma

```bash
python gui.py
```

Sistem tray'de ikon belirecek. Tunnel URL'ini kopyalayıp YouTube Hikaye Otomasyon paneline yapıştırın.

## 🔧 Kullanım

### API Endpoints

| Endpoint | Method | Açıklama |
|----------|--------|----------|
| `/api/health` | GET | Sunucu durumu |
| `/api/languages` | GET | Desteklenen diller |
| `/api/voices` | GET | Kayıtlı referans sesler |
| `/api/voices` | POST | Yeni ses yükle |
| `/api/voices/{id}` | DELETE | Ses sil |
| `/api/tts` | POST | Ses üret |

### TTS İsteği Örneği

```bash
curl -X POST "http://localhost:8765/api/tts" \
  -H "Content-Type: application/json" \
  -d '{"text": "Merhaba dünya!", "language": "tr", "voice_id": "abc123"}' \
  --output output.wav
```

### API Dokümantasyonu

Sunucu çalışırken: http://localhost:8765/docs

## 📦 EXE Oluşturma

### Otomatik (Önerilen)

```batch
build.bat
```

Bu script:
1. Sanal ortam oluşturur
2. Bağımlılıkları kurar
3. PyInstaller ile EXE oluşturur

### Manuel

```bash
# Sanal ortam
python -m venv venv
venv\Scripts\activate

# Kurulum
pip install -r requirements.txt
pip install pyinstaller

# Build
pyinstaller build.spec
```

Oluşan EXE: `dist/CoquiTTSServer/CoquiTTSServer.exe`

**Not:** 
- EXE klasörü ~2-3GB olacak (PyTorch + TTS model)
- İlk çalıştırmada XTTS v2 modeli indirilir (~2GB ek)

## 🚀 Hızlı Başlangıç (EXE Olmadan)

EXE oluşturmadan direkt Python ile çalıştırmak için:

```batch
run_server.bat
```

veya konsol modunda:

```batch
run_server_console.bat
```

## 🌐 Web Panelden Kullanım

1. Bu sunucuyu başlatın
2. Sistem tray'den Tunnel URL'ini kopyalayın
3. YouTube Hikaye Otomasyon panelinde:
   - Ayarlar > Seslendirme Sağlayıcısı > Coqui TTS seçin
   - Tunnel URL'ini yapıştırın
   - Bağlantı testini yapın
   - Referans ses yükleyin
   - Dil seçin

## 🎙️ Referans Ses Hazırlama

İyi bir ses klonlama için:

- **Süre**: 3-10 saniye
- **Format**: WAV veya MP3
- **Kalite**: Net, gürültüsüz kayıt
- **İçerik**: Düzgün, doğal konuşma

## ⚙️ Konfigürasyon

`config.py` dosyasını düzenleyin:

```python
# GPU kullanımı (False = CPU)
USE_GPU = True

# Sunucu portu
SERVER_PORT = 8765

# Model (değiştirmeyin)
TTS_MODEL = "tts_models/multilingual/multi-dataset/xtts_v2"
```

## 🐛 Sorun Giderme

### "cloudflared bulunamadı"
cloudflared'ı kurun veya PATH'e ekleyin.

### "CUDA out of memory"
GPU belleği yetersiz. `config.py`'de `USE_GPU = False` yapın.

### Model indirme hatası
İnternet bağlantınızı kontrol edin. Model Hugging Face'den indirilir.

### Ses kalitesi düşük
Daha iyi bir referans ses kullanın. En az 3 saniyelik net kayıt gerekir.

## 📝 Lisans

MIT License

## 🔗 Bağlantılar

- [Coqui TTS GitHub](https://github.com/coqui-ai/TTS)
- [XTTS v2 Model](https://huggingface.co/coqui/XTTS-v2)
- [Cloudflare Tunnel](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/)

