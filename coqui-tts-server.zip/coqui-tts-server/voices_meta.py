"""
Coqui TTS Server - Ses Meta Veri Yönetimi
Dahili ve özel seslerin meta verilerini yönetir.
"""

import json
import uuid
from pathlib import Path
from typing import Optional, List, Dict
from config import VOICES_DIR

# Meta veri dosyası
VOICES_META_FILE = VOICES_DIR / "voices_meta.json"

# Dahili sesler tanımları
BUILTIN_VOICES = [
    {
        "id": "builtin_tr_male_01",
        "name": "Türkçe Erkek 1",
        "language": "tr",
        "gender": "male",
        "type": "builtin",
        "description": "Doğal Türkçe erkek sesi",
        "preview_text": "Merhaba, ben dahili Türkçe erkek sesi. Hikayelerinizi seslendirebilirim."
    },
    {
        "id": "builtin_tr_female_01",
        "name": "Türkçe Kadın 1",
        "language": "tr",
        "gender": "female",
        "type": "builtin",
        "description": "Doğal Türkçe kadın sesi",
        "preview_text": "Merhaba, ben dahili Türkçe kadın sesi. Hikayelerinizi seslendirebilirim."
    },
    {
        "id": "builtin_en_male_01",
        "name": "English Male 1",
        "language": "en",
        "gender": "male",
        "type": "builtin",
        "description": "Natural English male voice",
        "preview_text": "Hello, I am the built-in English male voice. I can narrate your stories."
    },
    {
        "id": "builtin_en_female_01",
        "name": "English Female 1",
        "language": "en",
        "gender": "female",
        "type": "builtin",
        "description": "Natural English female voice",
        "preview_text": "Hello, I am the built-in English female voice. I can narrate your stories."
    },
    {
        "id": "builtin_de_male_01",
        "name": "Deutsch Mann 1",
        "language": "de",
        "gender": "male",
        "type": "builtin",
        "description": "Natürliche deutsche Männerstimme",
        "preview_text": "Hallo, ich bin die eingebaute deutsche Männerstimme."
    },
    {
        "id": "builtin_es_female_01",
        "name": "Español Mujer 1",
        "language": "es",
        "gender": "female",
        "type": "builtin",
        "description": "Voz femenina española natural",
        "preview_text": "Hola, soy la voz femenina española incorporada."
    },
    {
        "id": "builtin_fr_female_01",
        "name": "Français Femme 1",
        "language": "fr",
        "gender": "female",
        "type": "builtin",
        "description": "Voix féminine française naturelle",
        "preview_text": "Bonjour, je suis la voix féminine française intégrée."
    },
    {
        "id": "builtin_it_male_01",
        "name": "Italiano Uomo 1",
        "language": "it",
        "gender": "male",
        "type": "builtin",
        "description": "Voce maschile italiana naturale",
        "preview_text": "Ciao, sono la voce maschile italiana integrata."
    },
    {
        "id": "builtin_pt_female_01",
        "name": "Português Mulher 1",
        "language": "pt",
        "gender": "female",
        "type": "builtin",
        "description": "Voz feminina portuguesa natural",
        "preview_text": "Olá, sou a voz feminina portuguesa integrada."
    },
    {
        "id": "builtin_ru_male_01",
        "name": "Русский Мужчина 1",
        "language": "ru",
        "gender": "male",
        "type": "builtin",
        "description": "Естественный русский мужской голос",
        "preview_text": "Привет, я встроенный русский мужской голос."
    },
    {
        "id": "builtin_ja_female_01",
        "name": "日本語 女性 1",
        "language": "ja",
        "gender": "female",
        "type": "builtin",
        "description": "自然な日本語の女性の声",
        "preview_text": "こんにちは、私は内蔵の日本語女性音声です。"
    },
    {
        "id": "builtin_zh_male_01",
        "name": "中文 男性 1",
        "language": "zh-cn",
        "gender": "male",
        "type": "builtin",
        "description": "自然的中文男声",
        "preview_text": "你好，我是内置的中文男声。"
    },
    {
        "id": "builtin_ko_female_01",
        "name": "한국어 여성 1",
        "language": "ko",
        "gender": "female",
        "type": "builtin",
        "description": "자연스러운 한국어 여성 목소리",
        "preview_text": "안녕하세요, 저는 내장된 한국어 여성 음성입니다."
    },
    {
        "id": "builtin_ar_male_01",
        "name": "عربي ذكر 1",
        "language": "ar",
        "gender": "male",
        "type": "builtin",
        "description": "صوت ذكر عربي طبيعي",
        "preview_text": "مرحبا، أنا الصوت العربي الذكوري المدمج."
    },
]


class VoicesManager:
    """Ses meta verilerini yönetir"""
    
    def __init__(self):
        self.meta_file = VOICES_META_FILE
        self._ensure_meta_file()
    
    def _ensure_meta_file(self):
        """Meta veri dosyasının varlığını kontrol et"""
        if not self.meta_file.exists():
            self._save_meta({"custom_voices": []})
    
    def _load_meta(self) -> dict:
        """Meta veriyi yükle"""
        try:
            with open(self.meta_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {"custom_voices": []}
    
    def _save_meta(self, data: dict):
        """Meta veriyi kaydet"""
        with open(self.meta_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def get_all_voices(self) -> List[Dict]:
        """Tüm sesleri getir (dahili + özel)"""
        meta = self._load_meta()
        custom_voices = meta.get("custom_voices", [])
        
        # Dahili seslerin wav dosyası kontrolü
        available_builtin = []
        for voice in BUILTIN_VOICES:
            voice_file = VOICES_DIR / f"{voice['id']}.wav"
            voice_copy = voice.copy()
            voice_copy["available"] = voice_file.exists()
            available_builtin.append(voice_copy)
        
        # Özel seslerin wav dosyası kontrolü
        available_custom = []
        for voice in custom_voices:
            voice_file = VOICES_DIR / f"{voice['id']}.wav"
            if voice_file.exists():
                voice_copy = voice.copy()
                voice_copy["available"] = True
                available_custom.append(voice_copy)
        
        return available_builtin + available_custom
    
    def get_builtin_voices(self) -> List[Dict]:
        """Sadece dahili sesleri getir"""
        available = []
        for voice in BUILTIN_VOICES:
            voice_file = VOICES_DIR / f"{voice['id']}.wav"
            voice_copy = voice.copy()
            voice_copy["available"] = voice_file.exists()
            available.append(voice_copy)
        return available
    
    def get_custom_voices(self) -> List[Dict]:
        """Sadece özel sesleri getir"""
        meta = self._load_meta()
        custom_voices = meta.get("custom_voices", [])
        
        available = []
        for voice in custom_voices:
            voice_file = VOICES_DIR / f"{voice['id']}.wav"
            if voice_file.exists():
                voice_copy = voice.copy()
                voice_copy["available"] = True
                available.append(voice_copy)
        
        return available
    
    def get_voice(self, voice_id: str) -> Optional[Dict]:
        """Belirli bir sesi getir"""
        # Önce dahili seslerde ara
        for voice in BUILTIN_VOICES:
            if voice["id"] == voice_id:
                voice_copy = voice.copy()
                voice_file = VOICES_DIR / f"{voice_id}.wav"
                voice_copy["available"] = voice_file.exists()
                return voice_copy
        
        # Özel seslerde ara
        meta = self._load_meta()
        for voice in meta.get("custom_voices", []):
            if voice["id"] == voice_id:
                voice_file = VOICES_DIR / f"{voice_id}.wav"
                if voice_file.exists():
                    voice_copy = voice.copy()
                    voice_copy["available"] = True
                    return voice_copy
        
        return None
    
    def add_custom_voice(self, name: str, language: str, gender: str = "unknown") -> Dict:
        """Yeni özel ses ekle"""
        voice_id = f"custom_{uuid.uuid4().hex[:8]}"
        
        voice = {
            "id": voice_id,
            "name": name,
            "language": language,
            "gender": gender,
            "type": "custom",
            "description": f"Özel ses: {name}",
            "preview_text": self._get_preview_text(language)
        }
        
        meta = self._load_meta()
        meta["custom_voices"].append(voice)
        self._save_meta(meta)
        
        return voice
    
    def delete_custom_voice(self, voice_id: str) -> bool:
        """Özel sesi sil"""
        # Dahili ses silinemez
        for voice in BUILTIN_VOICES:
            if voice["id"] == voice_id:
                return False
        
        meta = self._load_meta()
        original_count = len(meta.get("custom_voices", []))
        meta["custom_voices"] = [v for v in meta.get("custom_voices", []) if v["id"] != voice_id]
        
        if len(meta["custom_voices"]) < original_count:
            self._save_meta(meta)
            
            # Ses dosyasını da sil
            voice_file = VOICES_DIR / f"{voice_id}.wav"
            if voice_file.exists():
                voice_file.unlink()
            
            return True
        
        return False
    
    def _get_preview_text(self, language: str) -> str:
        """Dile göre önizleme metni döndür"""
        preview_texts = {
            "tr": "Merhaba, bu benim sesim. Hikayelerinizi seslendirebilirim.",
            "en": "Hello, this is my voice. I can narrate your stories.",
            "de": "Hallo, das ist meine Stimme. Ich kann Ihre Geschichten erzählen.",
            "es": "Hola, esta es mi voz. Puedo narrar tus historias.",
            "fr": "Bonjour, c'est ma voix. Je peux raconter vos histoires.",
            "it": "Ciao, questa è la mia voce. Posso narrare le tue storie.",
            "pt": "Olá, esta é a minha voz. Posso narrar suas histórias.",
            "ru": "Привет, это мой голос. Я могу озвучить ваши истории.",
            "ja": "こんにちは、これは私の声です。あなたの物語を語ることができます。",
            "zh-cn": "你好，这是我的声音。我可以为你的故事配音。",
            "ko": "안녕하세요, 이것은 제 목소리입니다. 당신의 이야기를 들려드릴 수 있습니다.",
            "ar": "مرحبا، هذا صوتي. يمكنني سرد قصصك.",
        }
        return preview_texts.get(language, preview_texts["en"])


# Singleton instance
voices_manager = VoicesManager()

