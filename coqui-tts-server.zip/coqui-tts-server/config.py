"""
Coqui TTS Server - Konfigürasyon
"""

import os
from pathlib import Path

# Temel dizinler
BASE_DIR = Path(__file__).parent.resolve()
VOICES_DIR = BASE_DIR / "voices"
TEMP_DIR = BASE_DIR / "temp"
LOGS_DIR = BASE_DIR / "logs"

# Dizinleri oluştur
VOICES_DIR.mkdir(exist_ok=True)
TEMP_DIR.mkdir(exist_ok=True)
LOGS_DIR.mkdir(exist_ok=True)

# Server ayarları
SERVER_HOST = "127.0.0.1"
SERVER_PORT = 8765

# TTS Model
TTS_MODEL = "tts_models/multilingual/multi-dataset/xtts_v2"

# Desteklenen diller (XTTS v2)
SUPPORTED_LANGUAGES = [
    {"code": "tr", "name": "Türkçe"},
    {"code": "en", "name": "English"},
    {"code": "es", "name": "Español"},
    {"code": "fr", "name": "Français"},
    {"code": "de", "name": "Deutsch"},
    {"code": "it", "name": "Italiano"},
    {"code": "pt", "name": "Português"},
    {"code": "pl", "name": "Polski"},
    {"code": "ru", "name": "Русский"},
    {"code": "nl", "name": "Nederlands"},
    {"code": "cs", "name": "Čeština"},
    {"code": "ar", "name": "العربية"},
    {"code": "zh-cn", "name": "中文"},
    {"code": "ja", "name": "日本語"},
    {"code": "hu", "name": "Magyar"},
    {"code": "ko", "name": "한국어"},
    {"code": "hi", "name": "हिन्दी"},
]

# Cloudflare tunnel (isteğe bağlı)
CLOUDFLARED_PATH = os.environ.get("CLOUDFLARED_PATH", "cloudflared")

# GPU kullanımı
USE_GPU = True  # False yapılırsa CPU kullanılır (daha yavaş)

# Logging
LOG_LEVEL = "INFO"

