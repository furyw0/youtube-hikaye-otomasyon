"""
Coqui TTS Server - Ana Uygulama
FastAPI sunucusu + Cloudflare Tunnel
"""

import os
import uuid
import logging
import shutil
from pathlib import Path
from datetime import datetime
from typing import Optional
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.responses import FileResponse, JSONResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from config import (
    SERVER_HOST, SERVER_PORT, VOICES_DIR, TEMP_DIR, 
    SUPPORTED_LANGUAGES, LOG_LEVEL
)
from tts_engine import engine
from tunnel_manager import tunnel
from voices_meta import voices_manager

# Logging ayarla
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# Pydantic modelleri
class TTSRequest(BaseModel):
    text: str
    language: str = "tr"
    voice_id: str


class VoiceInfo(BaseModel):
    id: str
    name: str
    createdAt: str
    filePath: str


# Startup/Shutdown
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Uygulama başlangıç ve kapanış işlemleri"""
    # Startup
    logger.info("Coqui TTS Server başlatılıyor...")
    
    try:
        engine.initialize()
        logger.info("TTS Engine hazır")
    except Exception as e:
        logger.error(f"TTS Engine başlatılamadı: {e}")
    
    # Tunnel başlat (isteğe bağlı)
    try:
        tunnel.start(on_url=lambda url: logger.info(f"🔗 Tunnel URL: {url}"))
    except Exception as e:
        logger.warning(f"Tunnel başlatılamadı: {e}")
    
    yield
    
    # Shutdown
    logger.info("Kapatılıyor...")
    tunnel.stop()
    
    # Temp dosyalarını temizle
    for f in TEMP_DIR.glob("*"):
        try:
            f.unlink()
        except:
            pass


# FastAPI uygulaması
app = FastAPI(
    title="Coqui TTS Server",
    description="XTTS v2 ile ses üretimi",
    version="1.0.0",
    lifespan=lifespan
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ========== API Endpoints ==========

@app.get("/", response_class=HTMLResponse)
async def home():
    """Ana sayfa - Durum ve TTS Test"""
    status = engine.get_status()
    tunnel_status = tunnel.get_status()
    
    # Dilleri al
    languages_options = "".join([
        f'<option value="{lang["code"]}">{lang["name"]}</option>'
        for lang in SUPPORTED_LANGUAGES
    ])
    
    html = f"""
    <!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Coqui TTS Server</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{
                font-family: 'Segoe UI', system-ui, sans-serif;
                background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
                min-height: 100vh;
                color: #e8e8e8;
                padding: 20px;
            }}
            .page-container {{
                max-width: 1200px;
                margin: 0 auto;
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
            }}
            @media (max-width: 900px) {{
                .page-container {{
                    grid-template-columns: 1fr;
                }}
            }}
            .container {{
                background: rgba(255,255,255,0.05);
                backdrop-filter: blur(10px);
                border-radius: 20px;
                padding: 30px;
                border: 1px solid rgba(255,255,255,0.1);
                box-shadow: 0 25px 50px rgba(0,0,0,0.3);
            }}
            h1 {{
                font-size: 2rem;
                margin-bottom: 8px;
                background: linear-gradient(90deg, #00d9ff, #00ff88);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
            }}
            h2 {{
                font-size: 1.3rem;
                margin-bottom: 15px;
                color: #00d9ff;
                display: flex;
                align-items: center;
                gap: 10px;
            }}
            .subtitle {{ color: #888; margin-bottom: 20px; font-size: 0.9rem; }}
            .status {{
                display: grid;
                gap: 10px;
                margin-bottom: 20px;
            }}
            .status-item {{
                display: flex;
                justify-content: space-between;
                padding: 12px 15px;
                background: rgba(0,0,0,0.2);
                border-radius: 8px;
                font-size: 0.9rem;
            }}
            .status-label {{ color: #aaa; }}
            .status-value {{ font-weight: 600; }}
            .status-value.ok {{ color: #00ff88; }}
            .status-value.error {{ color: #ff4757; }}
            .links {{
                display: flex;
                gap: 10px;
                flex-wrap: wrap;
            }}
            .links a {{
                flex: 1;
                min-width: 120px;
                padding: 12px 20px;
                background: linear-gradient(135deg, #00d9ff, #0099ff);
                color: white;
                text-decoration: none;
                border-radius: 8px;
                text-align: center;
                font-weight: 600;
                font-size: 0.85rem;
                transition: transform 0.2s, box-shadow 0.2s;
            }}
            .links a:hover {{
                transform: translateY(-2px);
                box-shadow: 0 10px 30px rgba(0,217,255,0.3);
            }}
            .emoji {{ font-size: 1.1em; margin-right: 6px; }}
            .tunnel-box {{
                margin-bottom: 20px;
                padding: 15px;
                background: rgba(0,217,255,0.1);
                border: 1px solid rgba(0,217,255,0.3);
                border-radius: 10px;
            }}
            .tunnel-label {{
                font-size: 0.8rem;
                color: #00d9ff;
                margin-bottom: 8px;
                display: flex;
                align-items: center;
                gap: 6px;
            }}
            .tunnel-url-container {{
                display: flex;
                gap: 8px;
                align-items: center;
            }}
            .tunnel-url {{
                flex: 1;
                padding: 10px 12px;
                background: rgba(0,0,0,0.3);
                border: 1px solid rgba(255,255,255,0.1);
                border-radius: 6px;
                color: #00ff88;
                font-family: 'Consolas', monospace;
                font-size: 0.8rem;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }}
            .copy-btn {{
                padding: 10px 15px;
                background: linear-gradient(135deg, #00ff88, #00d9ff);
                border: none;
                border-radius: 6px;
                color: #1a1a2e;
                font-weight: 600;
                cursor: pointer;
                transition: transform 0.2s;
                font-size: 0.85rem;
            }}
            .copy-btn:hover {{
                transform: translateY(-2px);
            }}
            .no-tunnel {{
                color: #888;
                font-style: italic;
                font-size: 0.9rem;
            }}
            
            /* TTS Test Styles */
            .test-section {{
                margin-top: 0;
            }}
            .form-group {{
                margin-bottom: 15px;
            }}
            .form-group label {{
                display: block;
                margin-bottom: 6px;
                color: #aaa;
                font-size: 0.85rem;
                font-weight: 500;
            }}
            .form-group input,
            .form-group select,
            .form-group textarea {{
                width: 100%;
                padding: 12px 15px;
                background: rgba(0,0,0,0.3);
                border: 1px solid rgba(255,255,255,0.15);
                border-radius: 8px;
                color: #fff;
                font-size: 0.9rem;
                transition: border-color 0.2s;
            }}
            .form-group input:focus,
            .form-group select:focus,
            .form-group textarea:focus {{
                outline: none;
                border-color: #00d9ff;
            }}
            .form-group textarea {{
                min-height: 100px;
                resize: vertical;
                font-family: inherit;
            }}
            .form-group select {{
                cursor: pointer;
            }}
            .form-group select option {{
                background: #1a1a2e;
                color: #fff;
            }}
            .file-input-wrapper {{
                position: relative;
                overflow: hidden;
                display: inline-block;
                width: 100%;
            }}
            .file-input-wrapper input[type=file] {{
                position: absolute;
                left: 0;
                top: 0;
                opacity: 0;
                cursor: pointer;
                width: 100%;
                height: 100%;
            }}
            .file-input-label {{
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
                padding: 15px;
                background: rgba(0,217,255,0.1);
                border: 2px dashed rgba(0,217,255,0.4);
                border-radius: 10px;
                color: #00d9ff;
                cursor: pointer;
                transition: all 0.2s;
            }}
            .file-input-label:hover {{
                background: rgba(0,217,255,0.15);
                border-color: #00d9ff;
            }}
            .file-input-label.has-file {{
                background: rgba(0,255,136,0.1);
                border-color: rgba(0,255,136,0.4);
                color: #00ff88;
            }}
            .voice-select-row {{
                display: flex;
                gap: 10px;
            }}
            .voice-select-row select {{
                flex: 1;
            }}
            .voice-select-row .preview-btn {{
                padding: 12px 15px;
                background: rgba(138, 43, 226, 0.2);
                border: 1px solid rgba(138, 43, 226, 0.4);
                border-radius: 8px;
                color: #da70d6;
                cursor: pointer;
                transition: all 0.2s;
                font-size: 0.9rem;
            }}
            .voice-select-row .preview-btn:hover {{
                background: rgba(138, 43, 226, 0.3);
            }}
            .voice-select-row .preview-btn:disabled {{
                opacity: 0.5;
                cursor: not-allowed;
            }}
            .generate-btn {{
                width: 100%;
                padding: 15px;
                background: linear-gradient(135deg, #00ff88, #00d9ff);
                border: none;
                border-radius: 10px;
                color: #1a1a2e;
                font-size: 1rem;
                font-weight: 700;
                cursor: pointer;
                transition: transform 0.2s, box-shadow 0.2s;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
            }}
            .generate-btn:hover {{
                transform: translateY(-2px);
                box-shadow: 0 10px 30px rgba(0,255,136,0.3);
            }}
            .generate-btn:disabled {{
                opacity: 0.6;
                cursor: not-allowed;
                transform: none;
            }}
            .generate-btn.loading {{
                background: linear-gradient(135deg, #888, #666);
            }}
            .audio-result {{
                margin-top: 15px;
                padding: 15px;
                background: rgba(0,255,136,0.1);
                border: 1px solid rgba(0,255,136,0.3);
                border-radius: 10px;
                display: none;
            }}
            .audio-result.show {{
                display: block;
            }}
            .audio-result audio {{
                width: 100%;
                margin-top: 10px;
            }}
            .audio-result .result-label {{
                color: #00ff88;
                font-size: 0.85rem;
                margin-bottom: 5px;
            }}
            .error-message {{
                margin-top: 15px;
                padding: 15px;
                background: rgba(255,71,87,0.1);
                border: 1px solid rgba(255,71,87,0.3);
                border-radius: 10px;
                color: #ff4757;
                font-size: 0.9rem;
                display: none;
            }}
            .error-message.show {{
                display: block;
            }}
            .voices-list {{
                margin-top: 10px;
                max-height: 150px;
                overflow-y: auto;
                border: 1px solid rgba(255,255,255,0.1);
                border-radius: 8px;
            }}
            .voice-item {{
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 10px 12px;
                border-bottom: 1px solid rgba(255,255,255,0.05);
                font-size: 0.85rem;
            }}
            .voice-item:last-child {{
                border-bottom: none;
            }}
            .voice-item .voice-name {{
                color: #fff;
            }}
            .voice-item .voice-type {{
                font-size: 0.75rem;
                padding: 2px 8px;
                border-radius: 4px;
                background: rgba(0,217,255,0.2);
                color: #00d9ff;
            }}
            .voice-item .voice-type.custom {{
                background: rgba(138, 43, 226, 0.2);
                color: #da70d6;
            }}
            .upload-status {{
                margin-top: 10px;
                font-size: 0.85rem;
                color: #00ff88;
                display: none;
            }}
            .upload-status.show {{
                display: block;
            }}
            .upload-status.error {{
                color: #ff4757;
            }}
            .tab-buttons {{
                display: flex;
                gap: 10px;
                margin-bottom: 20px;
            }}
            .tab-btn {{
                flex: 1;
                padding: 12px;
                background: rgba(255,255,255,0.05);
                border: 1px solid rgba(255,255,255,0.1);
                border-radius: 8px;
                color: #888;
                cursor: pointer;
                font-size: 0.9rem;
                transition: all 0.2s;
            }}
            .tab-btn:hover {{
                background: rgba(255,255,255,0.1);
            }}
            .tab-btn.active {{
                background: rgba(0,217,255,0.15);
                border-color: rgba(0,217,255,0.4);
                color: #00d9ff;
            }}
            .tab-content {{
                display: none;
            }}
            .tab-content.active {{
                display: block;
            }}
        </style>
    </head>
    <body>
        <div class="page-container">
            <!-- Sol Panel: Durum -->
            <div class="container">
                <h1>🐸 Coqui TTS Server</h1>
                <p class="subtitle">XTTS v2 ile ses üretimi</p>
                
                <div class="tunnel-box">
                    <div class="tunnel-label">
                        <span>🌐</span> Cloudflare Tunnel URL
                    </div>
                    {f'''
                    <div class="tunnel-url-container">
                        <div class="tunnel-url" id="tunnelUrl">{tunnel_status['url']}</div>
                        <button class="copy-btn" onclick="copyUrl()">📋 Kopyala</button>
                    </div>
                    ''' if tunnel_status['url'] else '<p class="no-tunnel">Tunnel henüz bağlanmadı...</p>'}
                </div>
                
                <div class="status">
                    <div class="status-item">
                        <span class="status-label">Model Durumu</span>
                        <span class="status-value {'ok' if status['model_loaded'] else 'error'}">
                            {'✅ Yüklendi' if status['model_loaded'] else '❌ Yüklenmedi'}
                        </span>
                    </div>
                    <div class="status-item">
                        <span class="status-label">Cihaz</span>
                        <span class="status-value {'ok' if status['gpu'] else ''}">
                            {'🎮 ' + (status['gpu_name'] or 'GPU') if status['gpu'] else '💻 CPU'}
                        </span>
                    </div>
                    <div class="status-item">
                        <span class="status-label">Tunnel</span>
                        <span class="status-value {'ok' if tunnel_status['url'] else 'error'}">
                            {'🌐 Aktif' if tunnel_status['url'] else '❌ Kapalı'}
                        </span>
                    </div>
                </div>
                
                <div class="links">
                    <a href="/docs"><span class="emoji">📖</span>API Docs</a>
                    <a href="/api/health"><span class="emoji">💚</span>Health</a>
                    <a href="/api/voices"><span class="emoji">🎤</span>Sesler</a>
                </div>
            </div>
            
            <!-- Sağ Panel: TTS Test -->
            <div class="container test-section">
                <h2>🎙️ TTS Test</h2>
                
                <!-- Tab Buttons -->
                <div class="tab-buttons">
                    <button class="tab-btn active" onclick="switchTab('test')">🔊 Ses Üret</button>
                    <button class="tab-btn" onclick="switchTab('upload')">📤 Ses Yükle</button>
                    <button class="tab-btn" onclick="switchTab('voices')">🎤 Seslerim</button>
                </div>
                
                <!-- Tab: Test -->
                <div id="tab-test" class="tab-content active">
                    <div class="form-group">
                        <label>📝 Metin</label>
                        <textarea id="ttsText" placeholder="Seslendirmek istediğiniz metni girin...">Merhaba, ben Coqui TTS. Hikayelerinizi seslendirebilirim.</textarea>
                    </div>
                    
                    <div class="form-group">
                        <label>🌍 Dil</label>
                        <select id="ttsLanguage">
                            {languages_options}
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>🎤 Referans Ses</label>
                        <div class="voice-select-row">
                            <select id="ttsVoice">
                                <option value="">Yükleniyor...</option>
                            </select>
                            <button class="preview-btn" onclick="previewVoice()" id="previewBtn" disabled>
                                ▶️ Önizle
                            </button>
                        </div>
                    </div>
                    
                    <button class="generate-btn" onclick="generateTTS()" id="generateBtn">
                        <span>🎵</span> Ses Üret
                    </button>
                    
                    <div class="audio-result" id="audioResult">
                        <div class="result-label">✅ Ses Oluşturuldu</div>
                        <audio id="audioPlayer" controls></audio>
                    </div>
                    
                    <div class="error-message" id="errorMessage"></div>
                </div>
                
                <!-- Tab: Upload -->
                <div id="tab-upload" class="tab-content">
                    <div class="form-group">
                        <label>📛 Ses Adı</label>
                        <input type="text" id="voiceName" placeholder="Örn: Benim Sesim">
                    </div>
                    
                    <div class="form-group">
                        <label>🌍 Dil</label>
                        <select id="voiceLanguage">
                            {languages_options}
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>👤 Cinsiyet</label>
                        <select id="voiceGender">
                            <option value="male">👨 Erkek</option>
                            <option value="female">👩 Kadın</option>
                            <option value="unknown">🧑 Belirtilmemiş</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>🎵 Ses Dosyası</label>
                        <div class="file-input-wrapper">
                            <div class="file-input-label" id="fileLabel">
                                <span>📁</span>
                                <span>WAV veya MP3 dosyası seçin</span>
                            </div>
                            <input type="file" id="voiceFile" accept=".wav,.mp3,audio/wav,audio/mpeg" onchange="handleFileSelect(this)">
                        </div>
                    </div>
                    
                    <button class="generate-btn" onclick="uploadVoice()" id="uploadBtn">
                        <span>📤</span> Ses Yükle
                    </button>
                    
                    <div class="upload-status" id="uploadStatus"></div>
                </div>
                
                <!-- Tab: Voices -->
                <div id="tab-voices" class="tab-content">
                    <p style="color: #888; font-size: 0.85rem; margin-bottom: 15px;">Kayıtlı referans sesleriniz:</p>
                    <div class="voices-list" id="voicesList">
                        <p style="padding: 15px; color: #666;">Yükleniyor...</p>
                    </div>
                </div>
            </div>
        </div>
        
        <script>
            // Tab değiştirme
            function switchTab(tab) {{
                document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
                
                event.target.classList.add('active');
                document.getElementById('tab-' + tab).classList.add('active');
                
                if (tab === 'voices') loadVoicesList();
            }}
            
            // Sesleri yükle
            async function loadVoices() {{
                try {{
                    const res = await fetch('/api/voices');
                    const data = await res.json();
                    
                    const select = document.getElementById('ttsVoice');
                    select.innerHTML = '<option value="">Ses seçin...</option>';
                    
                    // Dahili sesler
                    const builtin = data.builtin || [];
                    if (builtin.length > 0) {{
                        const group = document.createElement('optgroup');
                        group.label = '📦 Dahili Sesler';
                        builtin.filter(v => v.available).forEach(v => {{
                            const opt = document.createElement('option');
                            opt.value = v.id;
                            opt.textContent = v.name + ' (' + (v.language || '').toUpperCase() + ')';
                            group.appendChild(opt);
                        }});
                        if (group.children.length > 0) select.appendChild(group);
                    }}
                    
                    // Özel sesler
                    const custom = data.custom || [];
                    if (custom.length > 0) {{
                        const group = document.createElement('optgroup');
                        group.label = '👤 Özel Seslerim';
                        custom.forEach(v => {{
                            const opt = document.createElement('option');
                            opt.value = v.id;
                            opt.textContent = v.name;
                            group.appendChild(opt);
                        }});
                        select.appendChild(group);
                    }}
                    
                    document.getElementById('previewBtn').disabled = false;
                }} catch (e) {{
                    console.error('Sesler yüklenemedi:', e);
                }}
            }}
            
            // Sesler listesi
            async function loadVoicesList() {{
                try {{
                    const res = await fetch('/api/voices');
                    const data = await res.json();
                    
                    const list = document.getElementById('voicesList');
                    let html = '';
                    
                    const allVoices = [...(data.builtin || []), ...(data.custom || [])];
                    
                    if (allVoices.length === 0) {{
                        html = '<p style="padding: 15px; color: #666;">Henüz ses yok.</p>';
                    }} else {{
                        allVoices.forEach(v => {{
                            const typeClass = v.type === 'custom' ? 'custom' : '';
                            const typeLabel = v.type === 'custom' ? 'Özel' : 'Dahili';
                            const available = v.available !== false ? '✅' : '⚠️';
                            html += `
                                <div class="voice-item">
                                    <span class="voice-name">${{available}} ${{v.name}}</span>
                                    <span class="voice-type ${{typeClass}}">${{typeLabel}}</span>
                                </div>
                            `;
                        }});
                    }}
                    
                    list.innerHTML = html;
                }} catch (e) {{
                    document.getElementById('voicesList').innerHTML = '<p style="padding: 15px; color: #ff4757;">Hata: ' + e.message + '</p>';
                }}
            }}
            
            // TTS üret
            async function generateTTS() {{
                const text = document.getElementById('ttsText').value.trim();
                const language = document.getElementById('ttsLanguage').value;
                const voiceId = document.getElementById('ttsVoice').value;
                
                if (!text) {{
                    showError('Lütfen bir metin girin.');
                    return;
                }}
                if (!voiceId) {{
                    showError('Lütfen bir referans ses seçin.');
                    return;
                }}
                
                const btn = document.getElementById('generateBtn');
                btn.disabled = true;
                btn.classList.add('loading');
                btn.innerHTML = '<span>⏳</span> Üretiliyor...';
                
                hideError();
                document.getElementById('audioResult').classList.remove('show');
                
                try {{
                    const res = await fetch('/api/tts', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ text, language, voice_id: voiceId }})
                    }});
                    
                    if (!res.ok) {{
                        const err = await res.json();
                        throw new Error(err.detail || 'Ses üretilemedi');
                    }}
                    
                    const blob = await res.blob();
                    const url = URL.createObjectURL(blob);
                    
                    const audio = document.getElementById('audioPlayer');
                    audio.src = url;
                    document.getElementById('audioResult').classList.add('show');
                    audio.play();
                    
                }} catch (e) {{
                    showError(e.message);
                }} finally {{
                    btn.disabled = false;
                    btn.classList.remove('loading');
                    btn.innerHTML = '<span>🎵</span> Ses Üret';
                }}
            }}
            
            // Ses önizleme
            async function previewVoice() {{
                const voiceId = document.getElementById('ttsVoice').value;
                if (!voiceId) return;
                
                const btn = document.getElementById('previewBtn');
                btn.disabled = true;
                btn.textContent = '⏳...';
                
                try {{
                    const res = await fetch(`/api/voices/${{voiceId}}/preview`);
                    if (!res.ok) throw new Error('Önizleme alınamadı');
                    
                    const blob = await res.blob();
                    const url = URL.createObjectURL(blob);
                    const audio = new Audio(url);
                    audio.play();
                }} catch (e) {{
                    showError('Önizleme: ' + e.message);
                }} finally {{
                    btn.disabled = false;
                    btn.textContent = '▶️ Önizle';
                }}
            }}
            
            // Dosya seçildi
            function handleFileSelect(input) {{
                const label = document.getElementById('fileLabel');
                if (input.files.length > 0) {{
                    label.innerHTML = '<span>✅</span><span>' + input.files[0].name + '</span>';
                    label.classList.add('has-file');
                }} else {{
                    label.innerHTML = '<span>📁</span><span>WAV veya MP3 dosyası seçin</span>';
                    label.classList.remove('has-file');
                }}
            }}
            
            // Ses yükle
            async function uploadVoice() {{
                const name = document.getElementById('voiceName').value.trim();
                const language = document.getElementById('voiceLanguage').value;
                const gender = document.getElementById('voiceGender').value;
                const file = document.getElementById('voiceFile').files[0];
                
                if (!name) {{
                    showUploadStatus('Lütfen ses adı girin.', true);
                    return;
                }}
                if (!file) {{
                    showUploadStatus('Lütfen bir ses dosyası seçin.', true);
                    return;
                }}
                
                const btn = document.getElementById('uploadBtn');
                btn.disabled = true;
                btn.innerHTML = '<span>⏳</span> Yükleniyor...';
                
                try {{
                    const formData = new FormData();
                    formData.append('audio', file);
                    formData.append('name', name);
                    formData.append('language', language);
                    formData.append('gender', gender);
                    
                    const res = await fetch('/api/voices', {{
                        method: 'POST',
                        body: formData
                    }});
                    
                    const data = await res.json();
                    
                    if (data.success) {{
                        showUploadStatus('✅ Ses başarıyla yüklendi: ' + data.voice.name, false);
                        document.getElementById('voiceName').value = '';
                        document.getElementById('voiceFile').value = '';
                        document.getElementById('fileLabel').innerHTML = '<span>📁</span><span>WAV veya MP3 dosyası seçin</span>';
                        document.getElementById('fileLabel').classList.remove('has-file');
                        loadVoices();
                    }} else {{
                        throw new Error(data.detail || 'Yükleme başarısız');
                    }}
                }} catch (e) {{
                    showUploadStatus('❌ Hata: ' + e.message, true);
                }} finally {{
                    btn.disabled = false;
                    btn.innerHTML = '<span>📤</span> Ses Yükle';
                }}
            }}
            
            function showError(msg) {{
                const el = document.getElementById('errorMessage');
                el.textContent = '❌ ' + msg;
                el.classList.add('show');
            }}
            
            function hideError() {{
                document.getElementById('errorMessage').classList.remove('show');
            }}
            
            function showUploadStatus(msg, isError) {{
                const el = document.getElementById('uploadStatus');
                el.textContent = msg;
                el.classList.add('show');
                el.classList.toggle('error', isError);
            }}
            
            function copyUrl() {{
                const url = document.getElementById('tunnelUrl').textContent;
                navigator.clipboard.writeText(url);
            }}
            
            // Sayfa yüklendiğinde
            loadVoices();
        </script>
    </body>
    </html>
    """
    return HTMLResponse(content=html)


@app.get("/api/health")
async def health_check():
    """Sağlık kontrolü"""
    status = engine.get_status()
    tunnel_status = tunnel.get_status()
    
    return {
        "ok": status["model_loaded"],
        "gpu": status["gpu"],
        "modelLoaded": status["model_loaded"],
        "device": status["device"],
        "gpuName": status["gpu_name"],
        "model": status["model"],
        "tunnel": tunnel_status["url"],
        "version": "1.0.0"
    }


@app.get("/api/languages")
async def get_languages():
    """Desteklenen dilleri listele"""
    return {"languages": SUPPORTED_LANGUAGES}


@app.get("/api/voices")
async def list_voices():
    """Tüm sesleri listele (dahili + özel)"""
    all_voices = voices_manager.get_all_voices()
    
    # Dahili ve özel olarak ayır
    builtin = [v for v in all_voices if v.get("type") == "builtin"]
    custom = [v for v in all_voices if v.get("type") == "custom"]
    
    return {
        "voices": all_voices,
        "builtin": builtin,
        "custom": custom,
        "total": len(all_voices),
        "builtinCount": len(builtin),
        "customCount": len(custom)
    }


@app.get("/api/voices/builtin")
async def list_builtin_voices():
    """Sadece dahili sesleri listele"""
    voices = voices_manager.get_builtin_voices()
    return {"voices": voices, "count": len(voices)}


@app.get("/api/voices/custom")
async def list_custom_voices():
    """Sadece özel sesleri listele"""
    voices = voices_manager.get_custom_voices()
    return {"voices": voices, "count": len(voices)}


@app.get("/api/voices/{voice_id}")
async def get_voice(voice_id: str):
    """Belirli bir sesin bilgilerini getir"""
    voice = voices_manager.get_voice(voice_id)
    
    if not voice:
        raise HTTPException(status_code=404, detail="Ses bulunamadı")
    
    return {"voice": voice}


@app.get("/api/voices/{voice_id}/preview")
async def preview_voice(voice_id: str):
    """Sesin önizleme sesini üret ve döndür"""
    if not engine.model_loaded:
        raise HTTPException(status_code=503, detail="TTS modeli yüklenmemiş")
    
    voice = voices_manager.get_voice(voice_id)
    
    if not voice:
        raise HTTPException(status_code=404, detail="Ses bulunamadı")
    
    if not voice.get("available"):
        raise HTTPException(status_code=404, detail="Ses dosyası mevcut değil")
    
    # Önizleme ses dosyası var mı kontrol et
    preview_path = VOICES_DIR / f"{voice_id}_preview.wav"
    
    # Önizleme yoksa veya eskiyse oluştur
    voice_file = VOICES_DIR / f"{voice_id}.wav"
    if not preview_path.exists() or (voice_file.exists() and voice_file.stat().st_mtime > preview_path.stat().st_mtime):
        try:
            preview_text = voice.get("preview_text", "Hello, this is a voice preview.")
            language = voice.get("language", "en")
            
            engine.generate_speech(
                text=preview_text,
                language=language,
                voice_id=voice_id,
                output_path=preview_path
            )
            logger.info(f"Önizleme ses oluşturuldu: {voice_id}")
        except Exception as e:
            logger.error(f"Önizleme oluşturma hatası: {e}")
            raise HTTPException(status_code=500, detail=f"Önizleme oluşturulamadı: {e}")
    
    return FileResponse(
        path=preview_path,
        media_type="audio/wav",
        filename=f"{voice_id}_preview.wav"
    )


@app.post("/api/voices")
async def upload_voice(
    audio: UploadFile = File(...),
    name: str = Form(...),
    language: str = Form(default="tr"),
    gender: str = Form(default="unknown")
):
    """Yeni özel ses yükle"""
    try:
        # Meta veri oluştur
        voice = voices_manager.add_custom_voice(
            name=name,
            language=language,
            gender=gender
        )
        
        voice_path = VOICES_DIR / f"{voice['id']}.wav"
        
        # Dosyayı kaydet
        content = await audio.read()
        voice_path.write_bytes(content)
        
        logger.info(f"Yeni ses yüklendi: {voice['id']} ({name})")
        
        return {
            "success": True,
            "voice": voice
        }
        
    except Exception as e:
        logger.error(f"Ses yükleme hatası: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/voices/{voice_id}")
async def delete_voice(voice_id: str):
    """Özel ses sil (dahili sesler silinemez)"""
    voice = voices_manager.get_voice(voice_id)
    
    if not voice:
        raise HTTPException(status_code=404, detail="Ses bulunamadı")
    
    if voice.get("type") == "builtin":
        raise HTTPException(status_code=403, detail="Dahili sesler silinemez")
    
    try:
        success = voices_manager.delete_custom_voice(voice_id)
        
        if success:
            # Önizleme dosyasını da sil
            preview_path = VOICES_DIR / f"{voice_id}_preview.wav"
            preview_path.unlink(missing_ok=True)
            
            logger.info(f"Ses silindi: {voice_id}")
            return {"success": True}
        else:
            raise HTTPException(status_code=404, detail="Ses bulunamadı veya silinemedi")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Ses silme hatası: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/tts")
async def generate_tts(request: TTSRequest):
    """Metni sese çevir"""
    if not engine.model_loaded:
        raise HTTPException(status_code=503, detail="TTS modeli yüklenmemiş")
    
    # Çıktı dosyası
    output_id = str(uuid.uuid4())
    output_path = TEMP_DIR / f"{output_id}.wav"
    
    try:
        # Ses üret
        engine.generate_speech(
            text=request.text,
            language=request.language,
            voice_id=request.voice_id,
            output_path=output_path
        )
        
        # Dosyayı döndür
        return FileResponse(
            path=output_path,
            media_type="audio/wav",
            filename=f"tts_{output_id}.wav",
            background=None  # Dosyayı hemen sil değil
        )
        
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"TTS hatası: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ========== Ana Giriş Noktası ==========

def main():
    """Sunucuyu başlat"""
    import uvicorn
    
    logger.info(f"Sunucu başlatılıyor: http://{SERVER_HOST}:{SERVER_PORT}")
    
    uvicorn.run(
        app,
        host=SERVER_HOST,
        port=SERVER_PORT,
        log_level=LOG_LEVEL.lower()
    )


if __name__ == "__main__":
    main()

