"""
Cloudflare Tunnel Manager
cloudflared ile tunnel oluşturur ve yönetir
"""

import subprocess
import threading
import logging
import re
import time
from typing import Optional, Callable

from config import CLOUDFLARED_PATH, SERVER_PORT

logger = logging.getLogger(__name__)


class TunnelManager:
    """Cloudflare Tunnel yöneticisi"""
    
    def __init__(self):
        self.process: Optional[subprocess.Popen] = None
        self.tunnel_url: Optional[str] = None
        self.is_running = False
        self._on_url_callback: Optional[Callable[[str], None]] = None
        self._output_thread: Optional[threading.Thread] = None
        
    def check_cloudflared(self) -> bool:
        """cloudflared kurulu mu kontrol et"""
        try:
            result = subprocess.run(
                [CLOUDFLARED_PATH, "version"],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                logger.info(f"cloudflared bulundu: {result.stdout.strip()}")
                return True
        except FileNotFoundError:
            logger.warning("cloudflared bulunamadı")
        except Exception as e:
            logger.error(f"cloudflared kontrol hatası: {e}")
        return False
    
    def start(self, on_url: Optional[Callable[[str], None]] = None):
        """Tunnel başlat"""
        if self.is_running:
            logger.warning("Tunnel zaten çalışıyor")
            return
            
        if not self.check_cloudflared():
            raise RuntimeError(
                "cloudflared bulunamadı!\n\n"
                "Kurulum için:\n"
                "  winget install --id Cloudflare.cloudflared\n\n"
                "veya manuel indirin:\n"
                "  https://github.com/cloudflare/cloudflared/releases"
            )
        
        self._on_url_callback = on_url
        
        try:
            # Tunnel başlat
            self.process = subprocess.Popen(
                [
                    CLOUDFLARED_PATH,
                    "tunnel",
                    "--url", f"http://127.0.0.1:{SERVER_PORT}"
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )
            
            self.is_running = True
            
            # Output okuma thread'i
            self._output_thread = threading.Thread(target=self._read_output, daemon=True)
            self._output_thread.start()
            
            logger.info("Cloudflare tunnel başlatıldı")
            
        except Exception as e:
            logger.error(f"Tunnel başlatma hatası: {e}")
            raise
    
    def _read_output(self):
        """Tunnel çıktısını oku ve URL'i yakala"""
        url_pattern = re.compile(r'https://[a-z0-9-]+\.trycloudflare\.com')
        
        try:
            for line in iter(self.process.stdout.readline, ''):
                if not line:
                    break
                    
                line = line.strip()
                logger.debug(f"cloudflared: {line}")
                
                # URL'i yakala
                match = url_pattern.search(line)
                if match:
                    self.tunnel_url = match.group()
                    logger.info(f"Tunnel URL: {self.tunnel_url}")
                    
                    if self._on_url_callback:
                        self._on_url_callback(self.tunnel_url)
                        
        except Exception as e:
            logger.error(f"Output okuma hatası: {e}")
        finally:
            self.is_running = False
    
    def stop(self):
        """Tunnel durdur"""
        if self.process:
            try:
                self.process.terminate()
                self.process.wait(timeout=5)
            except:
                self.process.kill()
            
            self.process = None
            self.tunnel_url = None
            self.is_running = False
            logger.info("Tunnel durduruldu")
    
    def get_status(self) -> dict:
        """Tunnel durumunu döndür"""
        return {
            "running": self.is_running,
            "url": self.tunnel_url,
            "cloudflared_installed": self.check_cloudflared()
        }


# Singleton instance
tunnel = TunnelManager()

